# 仓库说明

本文从 `talking-alarm` 的仓库说明调整而来，适用于 Minibox。

## 通用

- 保持修改聚焦，优先选择简单、明确的方案，不顺带重构无关代码。
- 文件和目录使用英文无空格名称；C 源码和头文件使用小写下划线命名。
- 不自动生成 prompt 档案、开发日志或大量测试脚本；用户要求时再写。
- 用户明确要求保持构建简单，不要添加自定义构建框架或过多 Python 测试。
- 不默认创建虚拟环境；ESP-IDF 使用已安装的 Python 环境。

## 目录

- `esp32_idf_s3n16r8/`：独立 ESP-IDF 固件项目。
- `models/`：3D 模型、STL、3MF、机械尺寸说明及模型检查脚本。
- `docs/`：模块参数、接线及其他项目文档。
- `.github/skills/`：构建、开发日志及 PCB 设计布线技能。
- 不依赖 `C:\gitroot\talking-alarm` 运行或构建；该仓库只作参考。

## 固件与硬件

- 使用 ESP-IDF 5.3.5、C 和 FreeRTOS，不引入 Arduino 草图结构。
- 主控为 ESP32-S3 N16R8：16 MB Quad Flash（DIO、80 MHz），
  8 MB Octal PSRAM（40 MHz）；目标固定为 `esp32s3`。
- 屏幕为 ST7796 SPI、横屏 480 × 320，使用乐鑫官方
  `espressif/esp_lcd_st7796` 组件，不套用参考项目的 ST7789 初始化；
  不引入 Arduino 或 TFT_eSPI。
- 屏幕接线：LED=GPIO9、SCK=GPIO10、SDI=GPIO11、DC/RS=GPIO12、
  Reset=GPIO13、CS=GPIO14。
- 当前改版四个机械轴分别接 GPIO4/5/6/7 与 GND，不接 VCC；
  默认低有效并使用内部上拉，可在菜单中切换为高有效。
  摇杆 X=GPIO1、Y=GPIO2 的代码保留，但当前测试不启用。
  摇杆按压不使用，PCB 按压触点保持 NC；GPIO17 悬空 NC。
  RTC SDA=GPIO15、SCL=GPIO16，仅预留配置，当前未实现驱动。
- INMP441 SD=GPIO21、WS=GPIO39、SCK=GPIO40，L/R 接 GND（左声道）；
  模块正面视角左列从上到下为 L/R、WS、SCK，右列为 GND、VCC、SD。
  MAX98357 DIN=GPIO41、LRC=GPIO39、BCLK=GPIO40、SD/MODE=GPIO47、
  GAIN=GPIO42。GPIO47 播放时为高、其余时间为低，GPIO42 默认高阻；
  两模块半双工共用时钟，先释放当前 I2S 通道再切换；
  GPIO5 按住录音（最多 3 秒）、松开回放。
- GPIO48 控制板载 WS2812 RGB LED；启动时发送黑色数据熄灯。
  不要只拉低引脚，也不要误关 GPIO9 的屏幕背光。
- 逻辑电平及摇杆供电为 3.3 V，所有模块共地；屏幕 VCC 和背光驱动须遵守模块规格。
- GPIO19/20 保留给原生 USB，避免使用被 Octal PSRAM 占用的 GPIO35/36/37。
- 接线和参数的权威文档为 `docs/hardware-connections.md`，硬件变化时同步更新。

## PCB 设计与布线

- PCB 设计、布局、布线、包地审查和生产资料准备使用
  [design-route-minibox-pcb](skills/design-route-minibox-pcb/SKILL.md)。
- 嘉立创 PCB、全元件装配询价与下单使用
  [order-jlc-minibox](skills/order-jlc-minibox/SKILL.md)；
  区分贴片、插件与模块组装，数量和最终费用确认后才提交购买。
- 嘉立创工艺能力与项目推荐值见
  [PCB 设计规范](../docs/jlc-pcb-design-spec.md)；生产前核对最新官方参数。
- 工艺文档不代表现有 PCB 已达标；不得把未完成布线或未确认 BOM 的工程
  标记为可生产。`kicad` 原载板与 `kicad_ex` 集成工程分别维护。
- 修改PCB布局、封装、选型或引脚后，必须在同一任务同步实际PCB、
  生成/导出源码、精确型号/C编号BOM、工厂专用CPL、中心/角度修正报告、
  Gerber/钻孔、装配图、manifest及审核包；未通过导出门槛不得声称可下单。
  复用已验证的工厂库原点/零角映射，从新版PCB重算，不靠网页逐件手调。
- 当前载板资料固定在`kicad\assembly`与`kicad\fabrication`，
  不创建日期revision目录或并存旧报价入口；历史由Git提交保存。
  manifest用PCB/文件哈希验证配套，不用日期目录代替版本控制。
  工厂保存快照绑定PCB哈希，布局改变后不得当作新版已验证。
- 下单agent或sub-agent验证过的页面入口、按钮、步骤、失败原因和解决方式
  必须回写下单skill；项目元件ID、坐标/角度及修正值只放BOM/CPL/报告，
  不把具体订单参数、账号、地址或临时element_index写入skill。

## 构建、烧录与验证

- 在已经初始化的 ESP-IDF 5.3.5 PowerShell 中进入 `esp32_idf_s3n16r8`，
  直接执行 `idf.py build`。
- 用户明确要求烧录时执行 `idf.py -p COM8 flash`；当前实板端口为 COM8，
  换机、端口消失或存在歧义时先识别设备。
- 需要日志时使用 `idf.py -p COM8 monitor`，退出后释放串口。
- 优先增量构建，不随意执行 `fullclean`、删除构建缓存或重复 `set-target`。
- 使用最小必要验证。已有模型检查用标准库 unittest，不新增 Python 测试框架。
- 构建成功、烧录成功、初始化成功与肉眼确认屏幕/按键正常是不同结果，不能混为一谈。
- 当前测试无需摇杆校准；观察四个按钮的屏幕状态及 GPIO5 的录放音日志。

## 代码风格

- 沿用现有 C 命名和 `esp_err_t` 错误处理，配置常量集中管理。
- 模块职责清晰，不引入仅用于转发的多层封装。
- 错误通过返回码、ESP-IDF 日志或屏幕明确报告，不静默失败。
- 源码默认 ASCII，注释简短，只解释不明显的逻辑；中文文档保留 UTF-8。
- `sdkconfig.defaults` 保持 ASCII，避免 Windows 配置工具编码问题。

## 文档与版本控制

- 文档保持简洁，包含实际可用的命令和明确的硬件前提。
- 路径或使用方式变化时更新链接；机械模型的命令在 `models` 下执行。
- STL/3MF 及 `font_data/` 下带许可证的字体是需要保留的交付文件，
  不因其是导出产物而删除；普通构建不重新生成字体。
- 不提交 `build/`、生成的 `sdkconfig`、虚拟环境、缓存、临时串口日志或凭据。
- Git commit、push 和烧录需要用户明确请求；不强推，不覆盖他人的改动。
